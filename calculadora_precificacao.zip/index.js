import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function PricingApp() {
  const [cost, setCost] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [tax, setTax] = useState(6);
  const [freight, setFreight] = useState(0);
  const [expenses, setExpenses] = useState(5);
  const [profit, setProfit] = useState(20);
  const [finalPrice, setFinalPrice] = useState(0);

  useEffect(() => {
    calculatePrice();
  }, [cost, quantity, tax, freight, expenses, profit]);

  const calculatePrice = () => {
    const totalCost = cost * quantity;
    const taxAmount = (totalCost * tax) / 100;
    const expenseAmount = (totalCost * expenses) / 100;
    const profitAmount = ((totalCost + taxAmount + freight + expenseAmount) * profit) / 100;
    setFinalPrice(totalCost + taxAmount + freight + expenseAmount + profitAmount);
  };

  return (
    <div className="p-6 max-w-md mx-auto">
      <Card>
        <CardContent className="p-4 space-y-4">
          <h2 className="text-xl font-bold">Calculadora de Precificação</h2>
          <Input type="number" placeholder="Custo Unitário" onChange={(e) => setCost(parseFloat(e.target.value) || 0)} />
          <Input type="number" placeholder="Quantidade" onChange={(e) => setQuantity(parseInt(e.target.value) || 1)} />
          <Input type="number" placeholder="Impostos (%)" value={tax} onChange={(e) => setTax(parseFloat(e.target.value) || 0)} />
          <Input type="number" placeholder="Frete (R$)" onChange={(e) => setFreight(parseFloat(e.target.value) || 0)} />
          <Input type="number" placeholder="Despesas (%)" value={expenses} onChange={(e) => setExpenses(parseFloat(e.target.value) || 0)} />
          <Input type="number" placeholder="Lucro Desejado (%)" value={profit} onChange={(e) => setProfit(parseFloat(e.target.value) || 0)} />
          <Button onClick={calculatePrice} className="w-full bg-blue-500 text-white">Calcular</Button>
          <div className="text-lg font-semibold">Valor Final de Venda: R$ {finalPrice.toFixed(2)}</div>
        </CardContent>
      </Card>
    </div>
  );
}